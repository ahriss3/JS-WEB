function tribonacci(n) {
    if (n === 0) {
        return 0;
    } else if (n === 1 || n === 2) {
        return 1;
    } else {
        // Calcular f(n-1), f(n-2) e f(n-3) e somá-los
        return tribonacci(n - 1) + tribonacci(n - 2) + tribonacci(n - 3);
    }
}
const N = 8;
console.log("O", N + "-ésimo número da sequência de Tribonacci é:", tribonacci(N));