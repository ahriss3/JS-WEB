function pell(n) {
    if (n === 0) {
        return 0;
    } else if (n === 1) {
        return 1;
    } else {
        // Calcular p(n-1) e p(n-2) e somá-los multiplicando p(n-1) por 2
        return 2 * pell(n - 1) + pell(n - 2);
    }
}
const N = 6;
console.log("O", N + "-ésimo número de Pell é:", pell(N));