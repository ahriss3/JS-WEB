function potencia(x, k) {
    if (k === 0) {
        return 1;
    }
    if (k === 1) {
        return x;
    }
    if (k > 0 && k % 2 === 0) {
        return potencia(x * x, k / 2);
    }
    if (k > 0 && k % 2 !== 0) {
        return x * potencia(x, k - 1);
    }
    if (k < 0) {
        return 1 / potencia(x, -k);
    }
}
console.log(potencia(2, 3));
console.log(potencia(5, 0));
console.log(potencia(3, -2));