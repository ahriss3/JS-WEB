function somaInversoAteN(N) {
    if (N === 1) {
        return 1;
    } else {
        // Some 1/N com a soma dos inversos
        return 1 / N + somaInversoAteN(N - 1);
    }
}
console.log(somaInversoAteN(5));