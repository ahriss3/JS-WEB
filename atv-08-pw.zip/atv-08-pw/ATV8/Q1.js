function somaAteN(N) {
    if (N === 1) {
        return 1;
    } else {
        // Somar N com a soma de todos os números
        return N + somaAteN(N - 1);
    }
}
console.log(somaAteN(5)); // Saída: 15
